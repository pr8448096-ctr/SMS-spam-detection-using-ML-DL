from pathlib import Path
import argparse
import json
import re
import random
import numpy as np
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from data_utils import load_data

ROOT = Path(__file__).resolve().parents[1]
ART = ROOT / "artifacts"
ART.mkdir(exist_ok=True)
PAD, UNK = "<pad>", "<unk>"

def tokenize(text):
    return re.findall(r"[a-z]+|\d+|[^\w\s]", str(text).lower())

def build_vocab(texts, min_freq=2, max_vocab=20000):
    from collections import Counter
    counts = Counter(tok for text in texts for tok in tokenize(text))
    vocab = {PAD: 0, UNK: 1}
    for token, count in counts.most_common(max_vocab - 2):
        if count >= min_freq:
            vocab[token] = len(vocab)
    return vocab

def encode(text, vocab, max_len):
    ids = [vocab.get(tok, vocab[UNK]) for tok in tokenize(text)][:max_len]
    return ids + [0] * (max_len - len(ids))

class SMSData(Dataset):
    def __init__(self, texts, labels, vocab, max_len):
        self.x = torch.tensor([encode(t, vocab, max_len) for t in texts], dtype=torch.long)
        self.y = torch.tensor(np.asarray(labels, dtype=np.float32), dtype=torch.float32)
    def __len__(self): return len(self.y)
    def __getitem__(self, idx): return self.x[idx], self.y[idx]

class LSTMClassifier(nn.Module):
    def __init__(self, vocab_size, embedding_dim=64, hidden_dim=64, dropout=0.3):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        self.lstm = nn.LSTM(embedding_dim, hidden_dim, batch_first=True, bidirectional=True)
        self.dropout = nn.Dropout(dropout)
        self.fc = nn.Linear(hidden_dim * 2, 1)
    def forward(self, x):
        embedded = self.embedding(x)
        _, (hidden, _) = self.lstm(embedded)
        combined = torch.cat((hidden[-2], hidden[-1]), dim=1)
        return self.fc(self.dropout(combined)).squeeze(1)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--epochs", type=int, default=8)
    parser.add_argument("--max-len", type=int, default=100)
    parser.add_argument("--batch-size", type=int, default=64)
    args = parser.parse_args()
    random.seed(42); np.random.seed(42); torch.manual_seed(42)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    df = load_data()
    train_texts, test_texts, y_train, y_test = train_test_split(
        df["text"].astype(str).tolist(), df["target"].tolist(),
        test_size=0.2, random_state=42, stratify=df["target"]
    )
    train_texts, val_texts, y_train, y_val = train_test_split(
        train_texts, y_train, test_size=0.15, random_state=42, stratify=y_train
    )
    vocab = build_vocab(train_texts)
    train_ds = SMSData(train_texts, y_train, vocab, args.max_len)
    val_ds = SMSData(val_texts, y_val, vocab, args.max_len)
    test_ds = SMSData(test_texts, y_test, vocab, args.max_len)
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size)
    test_loader = DataLoader(test_ds, batch_size=args.batch_size)
    model = LSTMClassifier(len(vocab)).to(device)
    # Spam is the minority class; use a positive-class weight to reduce majority-class bias.
    positives = max(1, sum(y_train))
    pos_weight = torch.tensor([(len(y_train) - positives) / positives], device=device)
    criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    best_val_f1, best_state = -1, None
    for epoch in range(1, args.epochs + 1):
        model.train()
        running = 0.0
        for x, y in train_loader:
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad()
            loss = criterion(model(x), y)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            running += loss.item() * len(y)
        model.eval()
        val_true, val_pred = [], []
        with torch.no_grad():
            for x, y in val_loader:
                probs = torch.sigmoid(model(x.to(device))).cpu().numpy()
                val_pred.extend((probs >= 0.5).astype(int).tolist())
                val_true.extend(y.numpy().astype(int).tolist())
        val_f1 = f1_score(val_true, val_pred, zero_division=0)
        print(f"Epoch {epoch}/{args.epochs} | loss={running/len(train_ds):.4f} | val_f1={val_f1:.4f}")
        if val_f1 > best_val_f1:
            best_val_f1, best_state = val_f1, {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    model.load_state_dict(best_state)
    model.eval()
    y_true, y_pred = [], []
    with torch.no_grad():
        for x, y in test_loader:
            probs = torch.sigmoid(model(x.to(device))).cpu().numpy()
            y_pred.extend((probs >= 0.5).astype(int).tolist())
            y_true.extend(y.numpy().astype(int).tolist())
    result = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision_spam": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall_spam": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1_spam": float(f1_score(y_true, y_pred, zero_division=0)),
        "classification_report": classification_report(y_true, y_pred, target_names=["ham", "spam"], output_dict=True, zero_division=0),
        "confusion_matrix": confusion_matrix(y_true, y_pred).tolist(),
        "device": str(device),
    }
    torch.save({"state_dict": model.state_dict(), "vocab": vocab, "max_len": args.max_len, "embedding_dim": 64, "hidden_dim": 64}, ART / "dl_model.pt")
    (ART / "metrics_dl.json").write_text(json.dumps(result, indent=2))
    print("\nTest metrics:")
    print(json.dumps({k: result[k] for k in ["accuracy", "precision_spam", "recall_spam", "f1_spam", "device"]}, indent=2))
    print(f"Saved DL model and metrics in {ART}")

if __name__ == "__main__":
    main()
