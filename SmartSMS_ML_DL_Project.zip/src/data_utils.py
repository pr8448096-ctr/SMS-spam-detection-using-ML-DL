from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "SMSSpamCollection"

def load_data(path=DATA_PATH):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found at {path}. Run: python src/download_data.py"
        )
    # UCI file is tab-separated, with label in column 1 and message in column 2.
    df = pd.read_csv(path, sep="\t", header=None, names=["label", "text"], encoding="utf-8")
    df = df.dropna(subset=["label", "text"])
    df["label"] = df["label"].str.strip().str.lower()
    df = df[df["label"].isin(["ham", "spam"])].drop_duplicates(subset=["text"])
    df["target"] = (df["label"] == "spam").astype(int)
    return df.reset_index(drop=True)

def split_data(df, test_size=0.2, random_state=42):
    return train_test_split(
        df["text"].astype(str), df["target"],
        test_size=test_size, random_state=random_state, stratify=df["target"]
    )
