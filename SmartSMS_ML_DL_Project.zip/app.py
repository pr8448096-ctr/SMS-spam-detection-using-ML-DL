from pathlib import Path
import re
import joblib
import streamlit as st
import torch
from torch import nn

ROOT = Path(__file__).resolve().parent
ART = ROOT / "artifacts"
st.set_page_config(page_title="SmartSMS Spam Detector", page_icon="📩", layout="centered")

class LSTMClassifier(nn.Module):
    def __init__(self, vocab_size, embedding_dim=64, hidden_dim=64, dropout=0.3):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        self.lstm = nn.LSTM(embedding_dim, hidden_dim, batch_first=True, bidirectional=True)
        self.dropout = nn.Dropout(dropout)
        self.fc = nn.Linear(hidden_dim * 2, 1)
    def forward(self, x):
        embedded = self.embedding(x)
        _, (hidden, _) = self.lstm(embedded)
        return self.fc(self.dropout(torch.cat((hidden[-2], hidden[-1]), dim=1))).squeeze(1)

def tokenize(text):
    return re.findall(r"[a-z]+|\d+|[^\w\s]", str(text).lower())

@st.cache_resource
def load_ml():
    path = ART / "ml_model.joblib"
    return joblib.load(path) if path.exists() else None

@st.cache_resource
def load_dl():
    path = ART / "dl_model.pt"
    if not path.exists(): return None
    checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    vocab, max_len = checkpoint["vocab"], checkpoint["max_len"]
    model = LSTMClassifier(len(vocab), checkpoint["embedding_dim"], checkpoint["hidden_dim"])
    model.load_state_dict(checkpoint["state_dict"])
    model.eval()
    return model, vocab, max_len

def encode(text, vocab, max_len):
    ids = [vocab.get(tok, vocab.get("<unk>", 1)) for tok in tokenize(text)][:max_len]
    return ids + [0] * (max_len - len(ids))

st.title("📩 SmartSMS")
st.subheader("SMS Spam Detection using Machine Learning & Deep Learning")
st.write("Enter a message to check whether it resembles spam or a legitimate SMS.")
message = st.text_area("SMS message", placeholder="Congratulations! You have won a prize. Call now...", height=130)
available = []
ml = load_ml()
dl = load_dl()
if ml is not None: available.append("Machine Learning (best TF-IDF model)")
if dl is not None: available.append("Deep Learning (BiLSTM)")
if not available:
    st.warning("No trained model found. Run `python src/train_ml.py` and/or `python src/train_dl.py` first.")
else:
    choice = st.selectbox("Choose model", available)
    if st.button("Analyze message", type="primary", disabled=not message.strip()):
        if choice.startswith("Machine"):
            model = ml
            prediction = int(model.predict([message])[0])
            probability = None
            if hasattr(model, "predict_proba"):
                probability = float(model.predict_proba([message])[0][1])
        else:
            model, vocab, max_len = dl
            with torch.no_grad():
                x = torch.tensor([encode(message, vocab, max_len)], dtype=torch.long)
                probability = float(torch.sigmoid(model(x)).item())
                prediction = int(probability >= 0.5)
        if prediction == 1:
            st.error("🚨 Likely SPAM")
        else:
            st.success("✅ Likely HAM (legitimate message)")
        if probability is not None:
            st.metric("Estimated spam score", f"{probability:.1%}")
        st.caption("Predictions are model estimates, not a guarantee. Avoid clicking suspicious links or sharing personal information.")
st.divider()
st.caption("Academic demo • Train/test performance depends on dataset and split.")
