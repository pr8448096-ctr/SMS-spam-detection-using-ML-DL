# SmartSMS — SMS Spam Detection with Machine Learning & Deep Learning

A complete, beginner-friendly ML + DL project that classifies an SMS message as **spam** or **ham (legitimate)**. It includes data downloading, exploratory analysis, a classical ML baseline, a PyTorch LSTM model, evaluation, and a Streamlit web app.

## Project highlights
- **Machine Learning:** TF-IDF + Logistic Regression and Multinomial Naive Bayes
- **Deep Learning:** Tokenized text + embedding + bidirectional LSTM (PyTorch)
- **Evaluation:** accuracy, precision, recall, F1, confusion matrix, classification report
- **Interactive app:** paste a message and get predictions from either trained model
- Reproducible split and saved model artifacts

## 1. Setup

Python 3.10 or 3.11 is recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

## 2. Download the dataset

```bash
python src/download_data.py
```

This downloads the UCI SMS Spam Collection dataset and saves it to `data/SMSSpamCollection`. Internet access is needed only for this step. If you already have the file, put it at that path.

## 3. Train and evaluate the ML models

```bash
python src/train_ml.py
```

This creates `artifacts/ml_model.joblib`, `artifacts/metrics_ml.json`, and a confusion-matrix image.

## 4. Train and evaluate the DL model

```bash
python src/train_dl.py --epochs 8
```

The first run builds the vocabulary and trains a bidirectional LSTM. Artifacts are saved under `artifacts/`.

## 5. Launch the app

```bash
streamlit run app.py
```

Train at least one model before opening the app. The app will show which models are available.

## Dataset
UCI Machine Learning Repository: SMS Spam Collection. The data contains SMS messages labeled `ham` or `spam`. It is intended for educational use. See the UCI dataset page for details: https://archive.ics.uci.edu/dataset/228/sms+spam+collection

## Repository structure

```text
SmartSMS/
├── app.py
├── requirements.txt
├── README.md
├── data/                 # downloaded dataset (not committed)
├── artifacts/            # trained models/metrics (created by scripts)
└── src/
    ├── download_data.py
    ├── data_utils.py
    ├── train_ml.py
    └── train_dl.py
```

## Notes for your college submission
- Suggested title: **SmartSMS: SMS Spam Detection Using Machine Learning and Deep Learning**
- You can extend it with multilingual messages, explainable predictions, model comparison charts, or an API.
- Do not claim perfect accuracy. Report the actual metrics produced on your test split.
- Include the dataset source and your own screenshots in the final report.

## Troubleshooting
- If downloading fails, download the dataset manually from the UCI page and place the extracted `SMSSpamCollection` file in `data/`.
- The LSTM may take a few minutes on CPU. Lower `--epochs` or use a smaller `--max_len` if needed.
- Run commands from the project root so relative paths resolve correctly.
