from pathlib import Path
import json
import joblib
import matplotlib.pyplot as plt
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    classification_report, ConfusionMatrixDisplay
)
from data_utils import load_data, split_data

ROOT = Path(__file__).resolve().parents[1]
ART = ROOT / "artifacts"
ART.mkdir(exist_ok=True)

def metrics(y_true, y_pred):
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision_spam": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall_spam": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1_spam": float(f1_score(y_true, y_pred, zero_division=0)),
        "classification_report": classification_report(
            y_true, y_pred, target_names=["ham", "spam"], output_dict=True, zero_division=0
        ),
    }

def main():
    df = load_data()
    X_train, X_test, y_train, y_test = split_data(df)
    models = {
        "logistic_regression": Pipeline([
            ("tfidf", TfidfVectorizer(lowercase=True, stop_words="english", ngram_range=(1, 2), min_df=2, sublinear_tf=True)),
            ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced", random_state=42)),
        ]),
        "naive_bayes": Pipeline([
            ("tfidf", TfidfVectorizer(lowercase=True, stop_words="english", ngram_range=(1, 2), min_df=2)),
            ("classifier", MultinomialNB()),
        ]),
    }
    results = {}
    best_name, best_f1, best_model = None, -1, None
    for name, model in models.items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        result = metrics(y_test, pred)
        results[name] = result
        print(f"\n=== {name} ===")
        print(f"Accuracy: {result['accuracy']:.4f} | Spam F1: {result['f1_spam']:.4f}")
        if result["f1_spam"] > best_f1:
            best_name, best_f1, best_model = name, result["f1_spam"], model
    joblib.dump(best_model, ART / "ml_model.joblib")
    (ART / "metrics_ml.json").write_text(json.dumps({"best_model": best_name, "models": results}, indent=2))
    ConfusionMatrixDisplay.from_estimator(best_model, X_test, y_test, display_labels=["Ham", "Spam"], cmap="Blues")
    plt.title(f"Best ML model: {best_name}")
    plt.tight_layout()
    plt.savefig(ART / "confusion_matrix_ml.png", dpi=160)
    plt.close()
    print(f"\nSaved best model ({best_name}) and metrics in {ART}")

if __name__ == "__main__":
    main()
