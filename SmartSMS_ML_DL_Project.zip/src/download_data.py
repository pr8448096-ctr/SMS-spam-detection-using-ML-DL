from pathlib import Path
import io
import zipfile
import requests

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)
URL = "https://archive.ics.uci.edu/static/public/228/sms+spam+collection.zip"

def main():
    target = DATA_DIR / "SMSSpamCollection"
    if target.exists():
        print(f"Dataset already exists: {target}")
        return
    print("Downloading UCI SMS Spam Collection...")
    response = requests.get(URL, timeout=60)
    response.raise_for_status()
    with zipfile.ZipFile(io.BytesIO(response.content)) as archive:
        member = next((n for n in archive.namelist() if n.endswith("SMSSpamCollection")), None)
        if not member:
            raise RuntimeError("Could not find SMSSpamCollection inside downloaded archive.")
        target.write_bytes(archive.read(member))
    print(f"Saved dataset to {target}")

if __name__ == "__main__":
    main()
